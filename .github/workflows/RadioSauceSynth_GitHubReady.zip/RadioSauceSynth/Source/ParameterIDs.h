
#pragma once
#include <JuceHeader.h>
namespace IDs {
const juce::String oscMorph="oscMorph", subLevel="subLevel", noiseLevel="noiseLevel",
  unison="unison", detune="detune", spread="spread", fmAmount="fmAmount", drive="drive",
  filterType="filterType", cutoff="cutoff", resonance="resonance", filtEnvAmt="filtEnvAmt",
  ampA="ampA", ampD="ampD", ampS="ampS", ampR="ampR",
  filA="filA", filD="filD", filS="filS", filR="filR",
  chorusMix="chorusMix", delayTime="delayTime", delayFdbk="delayFdbk", delayMix="delayMix",
  reverbMix="reverbMix", crushAmt="crushAmt", compAmt="compAmt", width="width", limitOn="limitOn",
  macroBite="macroBite", macroBody="macroBody", macroAir="macroAir", macroSpace="macroSpace",
  style="style", newSauce="newSauce";
}
