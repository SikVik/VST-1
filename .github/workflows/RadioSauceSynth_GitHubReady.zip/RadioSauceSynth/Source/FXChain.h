
#pragma once
#include <JuceHeader.h>
struct FXChain{
    void prepare(double sr,int block,int ch){ juce::dsp::ProcessSpec s{sr,(juce::uint32)block,(juce::uint32)ch};
        chorus.prepare(s); reverb.prepare(s); delay.setMaximumDelayInSamples((int)(sr*2.0));
        mix.reset(sr,0.05); width.reset(sr,0.05); comp.setRatio(2.0f); comp.setThreshold(-12.0f);
        comp.setAttack(10.0f); comp.setRelease(100.0f);
    }
    void setParams(float chorusMix,float dMs,float dFb,float dMix,float rMix,float crush,float cAmt,float w,bool lim){
        limitOn=lim; mix.setTargetValue(dMix); width.setTargetValue(w);
        chorus.setMix(juce::jlimit(0.0f,1.0f,chorusMix)); chorus.setDepth(0.5f); chorus.setCentreDelay(7.0f); chorus.setRate(0.25f);
        juce::dsp::Reverb::Parameters rp; rp.roomSize=0.45f; rp.wetLevel=juce::jlimit(0.0f,1.0f,rMix); rp.dryLevel=1.0f-rp.wetLevel; rp.width=1.0f; rp.damping=0.35f; reverb.setParameters(rp);
        crushSteps=juce::jmap(crush,0.0f,1.0f,0.0f,64.0f); delaySamples=(int)juce::jlimit(1.0f,2.0f*48000.0f,dMs*48.0f); delayFb=juce::jlimit(0.0f,0.95f,dFb);
        makeup=juce::Decibels::decibelsToGain(juce::jmap(cAmt,0.0f,1.0f,0.0f,6.0f));
    }
    inline float processSample(int ch,float x){
        float y=x;
        if(crushSteps>1.0f){ float step=2.0f/crushSteps; y=std::floor((y+1.0f)/step)*step-1.0f; }
        float delayed=delay.popSample(ch); delay.pushSample(ch, y + delayed*delayFb);
        y=y*(1.0f-mix.getNextValue()) + delayed*mix.getNextValue();
        y=std::tanh(y*makeup*1.2f);
        return y;
    }
    void processBlock(juce::AudioBuffer<float>& b){
        juce::dsp::AudioBlock<float> block(b);
        chorus.process(juce::dsp::ProcessContextReplacing<float>(block));
        reverb.process(juce::dsp::ProcessContextReplacing<float>(block));
        for(int ch=0; ch<b.getNumChannels(); ++ch){ auto* d=b.getWritePointer(ch);
            for(int i=0;i<b.getNumSamples();++i) d[i]=processSample(ch,d[i]); }
        if(limitOn){ for(int ch=0; ch<b.getNumChannels(); ++ch){ auto* d=b.getWritePointer(ch);
            for(int i=0;i<b.getNumSamples();++i) d[i]=juce::jlimit(-0.89f,0.89f,d[i]); } }
    }
    juce::dsp::Chorus<float> chorus; juce::dsp::Reverb reverb; juce::dsp::DelayLine<float> delay{96000};
    juce::SmoothedValue<float> mix,width; float delayFb=0.3f; int delaySamples=4800; float crushSteps=0.0f; bool limitOn=true;
    juce::dsp::Compressor<float> comp; float makeup=1.0f;
};
