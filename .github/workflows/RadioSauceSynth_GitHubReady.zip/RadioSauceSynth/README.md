
# RadioSauce Synth (JUCE VST3)

A modern, radio-ready polysynth for pop & hip‑hop with a **New Sauce** generator.

See `.github/workflows/build.yml` for one‑click GitHub Actions builds.
